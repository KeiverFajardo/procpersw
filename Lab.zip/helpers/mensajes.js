require('colors');


const mostrarMenu = () => {

    return new Promise( resolve => {

        console.clear();
        console.log('=========================='.green);
        console.log('  Seleccione una opción'.green);
        console.log('==========================\n'.green);

        console.log(`${ '1.'.green } Cantidad de elementos de la lista`);
        console.log(`${ '2.'.green } Agregar un elemento`);
        console.log(`${ '3.'.green } Eliminar un elemento dada su posición en la lista`);
        console.log(`${ '4.'.green } Devolver un nodo dada su posición en la lista`);
        console.log(`${ '5.'.green } Calcular la media`);
        console.log(`${ '6.'.green } Calcular la desviación estándar`);
        console.log(`${ '7.'.green } Listar los valores de los nodos`);
        console.log(`${ '0.'.green } Salir \n`);

        const readline = require('readline').createInterface({
            input: process.stdin,
            output: process.stdout
        });

        readline.question('Seleccione una opción: ', (opt) => {
            readline.close();
            resolve(opt);
        })

    });
}

const pausa = () => {

    return new Promise( resolve => {
        const readline = require('readline').createInterface({
            input: process.stdin,
            output: process.stdout
        });
    
        readline.question(`\nPresione ${ 'ENTER'.green } para continuar\n`, (opt) => {
            readline.close();
            resolve();
        })
    });
}

module.exports = {
    mostrarMenu,
    pausa
}