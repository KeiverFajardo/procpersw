class Nodo {
    constructor(data) {
        this.data = data;
        this.next = null;
    }
}

module.exports = Nodo;