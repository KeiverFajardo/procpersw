const Nodo = require('./nodo');

class Nodos {

    constructor() {
        this.head = null;
        this.tail = null;
        this.size = 0;
    }

    //- Cantidad de elementos de la lista.
    cantidadElementosLista(){
        console.log("Cantidad de elementos de la lista:", this.size);
    }
    
    //- Agregar un elemento.
    agregarElemento( data = 0 ){
        const newNode = new Nodo(data);

        if (!this.head) {
            this.head = newNode;
            this.tail = newNode;
        } else {
            this.tail.next = newNode;
            this.tail = newNode;
        }

        this.size++;
        this.sum += data;
        this.squaredSum += data * data;
    }
    
    //- Eliminar un elemento dada su posición en la lista.
    eliminarElementoPosicion( index = 0 ){
        index -= 1; //Arreglo empieza en la posicion 0 hasta n-1; Al eliminar el primer nodo en la posicion 1 sera en la posicion 0 de la lista.
        if (index < 0 || index >= this.size || !this.head) {
            console.log("Índice fuera de rango o lista vacía");
        }
        else
        {
            let current = this.head;
            let prev = null;
            let currentIndex = 0;
    
            while (currentIndex < index) {
                prev = current;
                current = current.next;
                currentIndex++;
            }
    
            if (prev === null) {
                this.head = current.next;
            } else {
                prev.next = current.next;
            }
    
            if (index === this.size - 1) {
                this.tail = prev;
            }
    
            this.size--;
            this.sum -= current.data;
            this.squaredSum -= current.data * current.data;
            return current.data;
        }
    }
    
    //- Devolver un nodo dada su posición en la lista. 
    buscarNodoPosicion( index = 0 ){
        index -= 1; //Arreglo empieza en la posicion 0 hasta n-1; Al eliminar el primer nodo en la posicion 1 sera en la posicion 0 de la lista.
        if (index < 0 || index >= this.size || !this.head) {
            console.log("Índice fuera de rango o lista vacía");
        }
        else
        {
            let current = this.head;
            let currentIndex = 0;
    
            while (currentIndex < index) {
                current = current.next;
                currentIndex++;
            }
            console.log("Nodo en la posición " + index + ": ", current.data);
            return current;
        }
    }

    calcularMedia(){
        if (this.size === 0) {
            console.log("La lista esta vacía, no se puede calcular la media.");
        }
        else
        {
            let current = this.head;
            let sum = 0;
            let count = 0;
        
            while (current !== null) {
                sum = parseFloat(sum) + parseFloat(current.data);
                count++;
                current = current.next;
            }
            let media = parseFloat(sum) / parseFloat(count)
            console.log("Media: " + media.toFixed(2) + "\n");
            return media;
        }
    }

    calcularDesviacionEstandar(){
        if (this.size === 0) {
            console.log("La lista está vacía, no se puede calcular la desviación estandar");
        }
        else
        {
            // Calcular la media de los valores de los nodos
            const mean = this.calcularMedia();
                
            let current = this.head;
            let sumSquaredDifferences = 0;
            let count = 0;

            // Iterar sobre la lista encadenada para calcular la suma de diferencias al cuadrado
            while (current !== null) {
                const difference = current.data - mean;
                sumSquaredDifferences += difference * difference;
                count++;
                current = current.next;
            }

            // Calcular la desviación estándar usando la fórmula
            const variance = sumSquaredDifferences / (count - 1);
            const standardDeviation = Math.sqrt(variance);

            console.log("Desviacion Estandar:", standardDeviation.toFixed(2));
            return standardDeviation;
        }
    }

    listarValoresNodos(){
        if (this.size === 0) {
            console.log("La lista esta vacía.");
        }
        else
        {
            let current = this.head;
            const values = [];
    
            while (current !== null) {
                values.push(current.data);
                current = current.next;
            }
    
            console.log("Valores de los nodos en la lista:\n", values.join(" \n "));
        
        }
    }
}

module.exports = Nodos;